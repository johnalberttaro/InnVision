import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  Image,
  Modal,
  useWindowDimensions,
} from 'react-native';
import { colors, spacing, radius, fonts } from '../../utils/portalTheme';
import { Ionicons } from '@expo/vector-icons';
import ConfirmDialog from '../../components/shared/ConfirmDialog';

const WIDE_BREAKPOINT = 1024; // sidebar is fixed/always-visible above this
const SIDEBAR_WIDTH = 264;

// ─── Logo image ───────────────────────────────────────────────────────────
const LOGO_SOURCE = require('../../../assets/logo.png');
// ─────────────────────────────────────────────────────────────────────────

// Admin Portal menu — covers SRS Module 6 (Admin Management):
// Transaction 6.1 Manage Room Types & Rates, 6.2 Generate Occupancy &
// Revenue Reports. This is the module FrontDeskSidebar.jsx's comment
// pointed to ("they'll live in screens/admin/AdminSidebar.jsx when that
// module is built").
const MENU_SECTIONS = [
  {
    key: 'dashboard',
    icon: 'grid-outline',
    label: 'Dashboard',
  },
  {
    key: 'rooms',
    icon: 'bed-outline',
    label: 'Room Management',
    subItems: [
      { key: 'rooms:types', label: 'Room Types & Rates' },
    ],
  },
  {
    key: 'food',
    icon: 'restaurant-outline',
    label: 'Food & Dining',
    subItems: [
      { key: 'food:menu', label: 'Food Menu' },
    ],
  },
  {
    key: 'staff',
    icon: 'people-outline',
    label: 'Staff',
    subItems: [
      { key: 'staff:accounts', label: 'Front Desk Accounts' },
      { key: 'staff:frontdesk', label: 'Front Desk Roster' },
      { key: 'staff:fnb', label: 'F&B Accounts' },
      { key: 'staff:housekeeping', label: 'Housekeeping Accounts' },
      { key: 'staff:maintenance', label: 'Maintenance Accounts' },
    ],
  },
  {
    key: 'fd',
    icon: 'briefcase-outline',
    label: 'Front Desk Operations',
    // Admin can do everything a front desk staff member can — and more.
    // These mirror the Front Desk portal's menu (prefixed `fd:` to avoid
    // colliding with admin-only keys like `rooms:types`). Keys map 1:1 to
    // the same screens the Front Desk uses, so the admin effectively
    // operates the front desk from inside the Admin Portal.
    subItems: [
      // Was 6 separate entries (View/Pending/Confirmed/Check-ins/
      // Check-outs/Refunds Pending) — collapsed to one, matching
      // FrontDeskSidebar.jsx's own Reservation Management change. All 6
      // (plus Walk-In Check-In and Tape Chart, which Admin gets access to
      // for free through the same shared screen) are now tabs inside
      // ReservationsScreen.jsx itself. Key kept as 'fd:reservations:all'
      // so this still lands on a real, valid filterKey (the All tab).
      { key: 'fd:reservations:all', label: 'Reservations' },
      // Was 5 separate entries (List/Types/Availability/Status/
      // Maintenance) — collapsed to one, matching FrontDeskSidebar.jsx's
      // own Room Management change. All 5 are now tabs inside
      // RoomManagementScreen.jsx itself. Key kept as 'fd:rooms:list' so
      // this still lands on a real, valid section (the List tab).
      { key: 'fd:rooms:list', label: 'Room Management' },
      // Was 3 separate entries (Profiles/Records/Special Requests) —
      // collapsed to one, matching every other Front Desk Operations item.
      // All 3 (plus Inquiries, reachable only via the navbar shortcut,
      // same as before this refactor) are now tabs inside
      // GuestManagementScreen.jsx itself.
      { key: 'fd:guests:profiles', label: 'Guest Management' },
      // Was 5 separate entries (Records/Payments/Receipts/Outstanding
      // Balances/Transaction History) — collapsed to one. All 5 are now
      // tabs inside BillingManagementScreen.jsx itself.
      { key: 'fd:billing:records', label: 'Billing Management' },
      // Was 3 separate entries (Schedule/Status/Maintenance) — collapsed
      // to one. All 3 are now tabs inside HousekeepingManagementScreen.jsx
      // itself.
      { key: 'fd:housekeeping:schedule', label: 'Housekeeping' },
    ],
  },
  {
    key: 'reports',
    icon: 'bar-chart-outline',
    label: 'Reports & Analytics',
    subItems: [
      { key: 'reports:occupancy', label: 'Occupancy Report' },
      { key: 'reports:revenue', label: 'Revenue Report' },
      { key: 'reports:ratings', label: 'Guest Ratings' },
    ],
  },
];

/**
 * AdminSidebar — left navigation for the Admin Portal (superadmin role).
 * Structurally identical to FrontDeskSidebar.jsx by design — same
 * responsive behavior, same collapse/overlay pattern — just a different
 * (smaller, admin-scoped) menu tree and brand subtitle.
 *
 * Props:
 *  - activeKey: string             currently active menu/sub-item key
 *  - onNavigate: (key) => void     called when a leaf item is tapped
 *  - onLogout: () => void
 *  - adminName?: string
 *  - collapsed: boolean            (mobile only) whether the overlay is open
 *  - onClose: () => void           (mobile only) close the overlay
 */
export default function AdminSidebar({
  activeKey,
  onNavigate,
  onLogout,
  adminName = 'Admin',
  collapsed = false,
  onClose,
}) {
  const { width } = useWindowDimensions();
  const isWide = width >= WIDE_BREAKPOINT;

  const content = (
    <SidebarContent
      activeKey={activeKey}
      onNavigate={(key) => {
        onNavigate(key);
        if (!isWide && onClose) onClose();
      }}
      onLogout={onLogout}
      adminName={adminName}
    />
  );

  if (isWide) {
    return <View style={styles.fixedWrap}>{content}</View>;
  }

  return (
    <Modal visible={collapsed} transparent animationType="fade" onRequestClose={onClose}>
      <View style={styles.overlayBackdrop}>
        <TouchableOpacity style={styles.backdropTapArea} activeOpacity={1} onPress={onClose} />
        <View style={styles.overlayPanel}>{content}</View>
      </View>
    </Modal>
  );
}

function SidebarContent({ activeKey, onNavigate, onLogout, adminName }) {
  const initialExpanded = MENU_SECTIONS.find((section) =>
    section.subItems?.some((sub) => sub.key === activeKey)
  )?.key;
  const [expandedKey, setExpandedKey] = useState(initialExpanded || null);
  const [confirmingLogout, setConfirmingLogout] = useState(false);

  const toggleSection = (section) => {
    if (!section.subItems) {
      onNavigate(section.key);
      return;
    }
    setExpandedKey((prev) => (prev === section.key ? null : section.key));
  };

  return (
    <View style={styles.sidebar}>
      {/* Header */}
      <View style={styles.header}>
        {LOGO_SOURCE ? (
          <Image source={LOGO_SOURCE} style={styles.logoImage} resizeMode="contain" />
        ) : (
          <View style={styles.logoBadge}>
            <Text style={styles.logoBadgeText}>LOGO</Text>
          </View>
        )}
        <Text style={styles.brandName}>InnVision</Text>
        <Text style={styles.brandSubtitle}>Admin Portal</Text>
      </View>

      {/* Menu */}
      <ScrollView style={styles.menuScroll} showsVerticalScrollIndicator={false}>
        {MENU_SECTIONS.map((section) => {
          // Namespace-prefix match alongside the exact/subItems checks —
          // 'fd' no longer lists all 6 reservations:* sub-keys individually
          // (collapsed to 1, see below), so without this, a dashboard KPI
          // shortcut landing on 'fd:reservations:checkins' would fail to
          // highlight "Front Desk Operations" even though that's genuinely
          // where the user is. For every other section this is a strict
          // superset of the old check (still true), so no behavior change.
          const keyNamespace = section.key.split(':')[0];
          const isParentActive =
            activeKey === section.key ||
            activeKey.startsWith(`${keyNamespace}:`) ||
            section.subItems?.some((s) => s.key === activeKey);
          const isExpanded = expandedKey === section.key;

          return (
            <View key={section.key}>
              <TouchableOpacity
                style={[styles.menuItem, isParentActive && !section.subItems && styles.menuItemActive]}
                onPress={() => toggleSection(section)}
                activeOpacity={0.75}
              >
                <Ionicons
                  name={section.icon}
                  size={18}
                  color={isParentActive ? colors.white : 'rgba(255,255,255,0.85)'}
                  style={styles.menuIcon}
                />
                <Text style={[styles.menuLabel, isParentActive && styles.menuLabelActive]}>
                  {section.label}
                </Text>
                {section.subItems && (
                  <Ionicons
                    name={isExpanded ? 'chevron-down' : 'chevron-forward'}
                    size={13}
                    color="rgba(255,255,255,0.5)"
                  />
                )}
              </TouchableOpacity>

              {section.subItems && isExpanded && (
                <View style={styles.subMenu}>
                  {section.subItems.map((sub) => {
                    // Every row left in this list is now a collapsed group
                    // (each used to be several separate sub-items — see the
                    // comments above), so rather than hand-listing one OR
                    // clause per collapsed key, this reads any sub-item as
                    // active for any activeKey under its namespace: strip
                    // sub.key's last segment ('fd:guests:profiles' ->
                    // 'fd:guests') and prefix-match against that. Covers a
                    // dashboard shortcut or navbar shortcut landing on e.g.
                    // 'fd:reservations:checkins' or 'fd:guests:inquiries'
                    // directly, same as the exact-match would for the
                    // collapsed key itself.
                    const subNamespace = sub.key.split(':').slice(0, -1).join(':');
                    const isActive =
                      activeKey === sub.key || activeKey.startsWith(`${subNamespace}:`);
                    return (
                      <TouchableOpacity
                        key={sub.key}
                        style={[styles.subMenuItem, isActive && styles.subMenuItemActive]}
                        onPress={() => !sub.comingSoon && onNavigate(sub.key)}
                        activeOpacity={sub.comingSoon ? 1 : 0.75}
                        disabled={sub.comingSoon}
                      >
                        <View style={[styles.subDot, isActive && styles.subDotActive]} />
                        <Text
                          style={[
                            styles.subMenuLabel,
                            isActive && styles.subMenuLabelActive,
                            sub.comingSoon && styles.subMenuLabelDisabled,
                          ]}
                        >
                          {sub.label}
                        </Text>
                        {sub.comingSoon && (
                          <View style={styles.comingSoonBadge}>
                            <Text style={styles.comingSoonBadgeText}>Soon</Text>
                          </View>
                        )}
                      </TouchableOpacity>
                    );
                  })}
                </View>
              )}
            </View>
          );
        })}

        <TouchableOpacity
          style={styles.menuItem}
          onPress={() => setConfirmingLogout(true)}
          activeOpacity={0.75}
        >
          <Ionicons name="log-out-outline" size={18} color="rgba(255,255,255,0.85)" style={styles.menuIcon} />
          <Text style={styles.menuLabel}>Logout</Text>
        </TouchableOpacity>
      </ScrollView>

      {/* Profile footer */}
      <View style={styles.profileFooter}>
        <View style={styles.avatar}>
          <Text style={styles.avatarText}>{adminName.charAt(0).toUpperCase()}</Text>
        </View>
        <View style={styles.profileTextWrap}>
          <Text style={styles.profileName} numberOfLines={1}>{adminName}</Text>
          <Text style={styles.profileRole} numberOfLines={1}>Administrator</Text>
        </View>
        <TouchableOpacity onPress={() => setConfirmingLogout(true)} style={styles.quickLogout} accessibilityLabel="Log out">
          <Ionicons name="power-outline" size={16} color={colors.white} />
        </TouchableOpacity>
      </View>

      <ConfirmDialog
        visible={confirmingLogout}
        title="Log Out?"
        message="Are you sure you want to log out?"
        confirmLabel="Yes"
        cancelLabel="No"
        destructive
        onCancel={() => setConfirmingLogout(false)}
        onConfirm={() => {
          setConfirmingLogout(false);
          onLogout && onLogout();
        }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  fixedWrap: {
    width: SIDEBAR_WIDTH,
    height: '100%',
  },
  overlayBackdrop: {
    flex: 1,
    flexDirection: 'row',
    backgroundColor: 'rgba(0,0,0,0.4)',
  },
  overlayPanel: {
    width: SIDEBAR_WIDTH,
    height: '100%',
  },
  backdropTapArea: {
    flex: 1,
  },

  sidebar: {
    width: SIDEBAR_WIDTH,
    height: '100%',
    backgroundColor: colors.primary,
    borderRightWidth: 1,
    borderRightColor: 'rgba(255,255,255,0.08)',
  },

  header: {
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.xl,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.1)',
    alignItems: 'center',
  },
  logoImage: {
    width: 44,
    height: 44,
    marginBottom: spacing.sm,
  },
  logoBadge: {
    width: 44,
    height: 44,
    borderRadius: 22,
    borderWidth: 1.5,
    borderColor: 'rgba(255,255,255,0.3)',
    borderStyle: 'dashed',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.sm,
  },
  logoBadgeText: {
    fontSize: 8,
    fontFamily: fonts.bodySemiBold,
    color: 'rgba(255,255,255,0.6)',
  },
  brandName: {
    fontSize: 17,
    fontFamily: fonts.headingExtraBold,
    color: colors.white,
    letterSpacing: 0.3,
  },
  brandSubtitle: {
    fontSize: 10,
    fontFamily: fonts.body,
    color: 'rgba(255,255,255,0.6)',
    textAlign: 'center',
    marginTop: 2,
  },

  menuScroll: {
    flex: 1,
    paddingVertical: spacing.sm,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: spacing.sm + 2,
    paddingHorizontal: spacing.lg,
  },
  menuItemActive: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderLeftWidth: 3,
    borderLeftColor: colors.accent,
  },
  menuIcon: {
    width: 24,
  },
  menuLabel: {
    flex: 1,
    fontSize: 15,
    fontFamily: fonts.bodySemiBold,
    color: 'rgba(255,255,255,0.85)',
  },
  menuLabelActive: {
    color: colors.white,
  },
  chevron: {
    fontSize: 11,
    color: 'rgba(255,255,255,0.5)',
  },

  subMenu: {
    paddingBottom: spacing.xs,
  },
  subMenuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: spacing.sm,
    paddingLeft: spacing.lg + 24,
    paddingRight: spacing.lg,
  },
  subMenuItemActive: {
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  subDot: {
    width: 5,
    height: 5,
    borderRadius: 3,
    backgroundColor: 'rgba(255,255,255,0.35)',
    marginRight: spacing.sm,
  },
  subDotActive: {
    backgroundColor: colors.accent,
  },
  subMenuLabel: {
    fontSize: 14,
    fontFamily: fonts.body,
    color: 'rgba(255,255,255,0.65)',
    flex: 1,
    flexShrink: 1,
  },
  subMenuLabelActive: {
    color: colors.white,
    fontFamily: fonts.bodySemiBold,
  },
  subMenuLabelDisabled: {
    color: 'rgba(255,255,255,0.35)',
  },
  comingSoonBadge: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 999,
    paddingVertical: 2,
    paddingHorizontal: spacing.xs,
    marginLeft: spacing.xs,
  },
  comingSoonBadgeText: {
    fontSize: 9,
    fontFamily: fonts.bodySemiBold,
    color: 'rgba(255,255,255,0.55)',
    letterSpacing: 0.3,
  },

  profileFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.1)',
  },
  avatar: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: colors.accent,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: spacing.sm,
  },
  avatarText: {
    color: colors.white,
    fontFamily: fonts.headingBold,
    fontSize: 14,
  },
  profileTextWrap: {
    flex: 1,
  },
  profileName: {
    fontSize: 12,
    fontFamily: fonts.bodySemiBold,
    color: colors.white,
  },
  profileRole: {
    fontSize: 10,
    fontFamily: fonts.body,
    color: 'rgba(255,255,255,0.6)',
    marginTop: 1,
  },
  quickLogout: {
    width: 30,
    height: 30,
    borderRadius: 15,
    backgroundColor: 'rgba(255,255,255,0.1)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  quickLogoutIcon: {
    fontSize: 14,
    color: colors.white,
  },
});