import React, { useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  Image,
  Modal,
  useWindowDimensions,
} from 'react-native';
import { colors, spacing, radius, fonts } from '../../utils/portalTheme';
import { Ionicons } from '@expo/vector-icons';
import ConfirmDialog from '../../components/shared/ConfirmDialog';

const WIDE_BREAKPOINT = 1024; // sidebar is fixed/always-visible above this
const SIDEBAR_WIDTH = 264;

// ─── Logo image ───────────────────────────────────────────────────────────
const LOGO_SOURCE = require('../../../assets/logo.png');
// ─────────────────────────────────────────────────────────────────────────

// Sidebar menu structure. Each top-level item can have `subItems`; tapping
// a parent with sub-items expands/collapses them rather than navigating
// directly (parents with no sub-items, like Dashboard and Logout, navigate
// immediately on tap).
//
// NOTE: Reports & Analytics and Administration sections were removed from
// here — those are Admin Portal responsibilities, not Front Desk. They'll
// live in screens/admin/AdminSidebar.jsx when that module is built.
const MENU_SECTIONS = [
  {
    key: 'dashboard',
    icon: 'home-outline',
    label: 'Dashboard',
  },
  // Flat now (no subItems) — Walk-In Check-In, Tape Chart, and the 6
  // reservation-list filters (View/Pending/Confirmed/Check-ins/Check-outs/
  // Refunds Pending) all moved into a scrollable tab bar at the top of
  // ReservationsScreen.jsx itself, so there's nothing left to expand here.
  // Key is 'reservations:all' (not just 'reservations') so tapping this
  // lands directly on the All-bookings tab — a real, valid filterKey —
  // rather than on a bare namespace with no matching tab.
  {
    key: 'reservations:all',
    icon: 'calendar-outline',
    label: 'Reservation Management',
  },
  // Flat now (no subItems) — the 5 room-management sub-screens (List/
  // Types/Availability/Status/Maintenance) all moved into a scrollable
  // tab bar at the top of RoomManagementScreen.jsx itself, same treatment
  // Reservation Management got above. Key is 'rooms:list' (not just
  // 'rooms') so tapping this lands directly on the Room List tab — a
  // real, valid section — rather than on a bare namespace with no
  // matching tab.
  {
    key: 'rooms:list',
    icon: 'bed-outline',
    label: 'Room Management',
  },
  // Flat now (no subItems) — the 4 guest sub-screens (Profiles/Records/
  // Ratings/Inquiries) all moved into a scrollable tab bar at the top of
  // GuestManagementScreen.jsx itself, same treatment Reservation and Room
  // Management got. Key is 'guests:profiles' (not just 'guests') so
  // tapping this lands directly on the Guest Profiles tab.
  {
    key: 'guests:profiles',
    icon: 'people-outline',
    label: 'Guest Management',
  },
  // Same collapse for Billing (Records/Payments/Receipts) →
  // BillingManagementScreen.jsx.
  {
    key: 'billing:records',
    icon: 'card-outline',
    label: 'Billing Management',
  },
  // Same collapse for Housekeeping (Schedule/Room Cleaning Status/
  // Maintenance Requests) → HousekeepingManagementScreen.jsx.
  {
    key: 'housekeeping:schedule',
    icon: 'sparkles-outline',
    label: 'Housekeeping',
  },
  {
    key: 'foodorders',
    icon: 'restaurant-outline',
    label: 'Food Orders',
  },
];

/**
 * FrontDeskSidebar — left navigation for the Front Desk Staff portal.
 *
 * Responsive behavior:
 *  - Wide screens (>= 1024px, desktop): fixed, always-visible sidebar.
 *    `onMenuPress`/`collapsed` props are unused in this mode.
 *  - Narrow screens (< 1024px, tablet/mobile): sidebar is hidden by
 *    default and slides in as a full-height overlay when `collapsed` is
 *    false, triggered by a hamburger button the parent screen renders
 *    (see FrontDeskShell.jsx) and closed via `onClose`.
 *
 * Props:
 *  - activeKey: string             currently active menu/sub-item key
 *  - onNavigate: (key) => void     called when a leaf item is tapped
 *  - onLogout: () => void
 *  - staffName?: string
 *  - staffRole?: string
 *  - staffPhotoUrl?: string        current profile photo, if any (falls
 *                                  back to an initials avatar when absent)
 *  - collapsed: boolean            (mobile only) whether the overlay is open
 *  - onClose: () => void           (mobile only) close the overlay
 */
export default function FrontDeskSidebar({
  activeKey,
  onNavigate,
  onLogout,
  staffName = 'Front Desk Staff',
  staffRole = 'Front Desk',
  staffPhotoUrl,
  collapsed = false,
  onClose,
}) {
  const { width } = useWindowDimensions();
  const isWide = width >= WIDE_BREAKPOINT;

  const content = (
    <SidebarContent
      activeKey={activeKey}
      onNavigate={(key) => {
        onNavigate(key);
        if (!isWide && onClose) onClose();
      }}
      onLogout={onLogout}
      staffName={staffName}
      staffRole={staffRole}
      staffPhotoUrl={staffPhotoUrl}
    />
  );

  if (isWide) {
    return <View style={styles.fixedWrap}>{content}</View>;
  }

  // Narrow screens: render as a full-height overlay modal, closeable by
  // tapping the dimmed backdrop or by navigating to an item.
  return (
    <Modal visible={collapsed} transparent animationType="fade" onRequestClose={onClose}>
      <View style={styles.overlayBackdrop}>
        <TouchableOpacity style={styles.backdropTapArea} activeOpacity={1} onPress={onClose} />
        <View style={styles.overlayPanel}>{content}</View>
      </View>
    </Modal>
  );
}

function SidebarContent({ activeKey, onNavigate, onLogout, staffName, staffRole, staffPhotoUrl }) {
  // Auto-expand whichever section contains the active leaf item, so the
  // active page is always visible without staff needing to manually
  // re-open its parent section.
  const initialExpanded = MENU_SECTIONS.find((section) =>
    section.subItems?.some((sub) => sub.key === activeKey)
  )?.key;
  const [expandedKey, setExpandedKey] = useState(initialExpanded || null);
  const [confirmingLogout, setConfirmingLogout] = useState(false);

  const toggleSection = (section) => {
    if (!section.subItems) {
      onNavigate(section.key);
      return;
    }
    setExpandedKey((prev) => (prev === section.key ? null : section.key));
  };

  return (
    <View style={styles.sidebar}>
      {/* Header */}
      <View style={styles.header}>
        {LOGO_SOURCE ? (
          <Image source={LOGO_SOURCE} style={styles.logoImage} resizeMode="contain" />
        ) : (
          <View style={styles.logoBadge}>
            <Text style={styles.logoBadgeText}>LOGO</Text>
          </View>
        )}
        <Text style={styles.brandName}>InnVision</Text>
        <Text style={styles.brandSubtitle}>Front Desk Staff Portal</Text>
      </View>

      {/* Menu */}
      <ScrollView style={styles.menuScroll} showsVerticalScrollIndicator={false}>
        {MENU_SECTIONS.map((section) => {
          // Namespace-prefix match (e.g. 'reservations:' catches
          // 'reservations:checkins') alongside the exact/subItems checks —
          // needed for flat items like Reservation Management, which can be
          // reached at a filterKey other than its own (a dashboard KPI
          // shortcut can land on 'reservations:checkins' directly) without
          // ever going through this sidebar. For every section that still
          // has subItems, section.key itself has no colon in it, so this
          // reduces to the exact same match it already had — no behavior
          // change for Room/Guest/Billing/Housekeeping management etc.
          const keyNamespace = section.key.split(':')[0];
          const isParentActive =
            activeKey === section.key ||
            activeKey.startsWith(`${keyNamespace}:`) ||
            section.subItems?.some((s) => s.key === activeKey);
          const isExpanded = expandedKey === section.key;

          return (
            <View key={section.key}>
              <TouchableOpacity
                style={[styles.menuItem, isParentActive && !section.subItems && styles.menuItemActive]}
                onPress={() => toggleSection(section)}
                activeOpacity={0.75}
              >
                <Ionicons
                  name={section.icon}
                  size={18}
                  color={isParentActive ? colors.white : 'rgba(255,255,255,0.85)'}
                  style={styles.menuIcon}
                />
                <Text style={[styles.menuLabel, isParentActive && styles.menuLabelActive]}>
                  {section.label}
                </Text>
                {section.subItems && (
                  <Ionicons
                    name={isExpanded ? 'chevron-down' : 'chevron-forward'}
                    size={13}
                    color="rgba(255,255,255,0.5)"
                  />
                )}
              </TouchableOpacity>

              {section.subItems && isExpanded && (
                <View style={styles.subMenu}>
                  {section.subItems.map((sub) => {
                    const isActive = activeKey === sub.key;
                    return (
                      <TouchableOpacity
                        key={sub.key}
                        style={[styles.subMenuItem, isActive && styles.subMenuItemActive]}
                        onPress={() => onNavigate(sub.key)}
                        activeOpacity={0.75}
                      >
                        <View style={[styles.subDot, isActive && styles.subDotActive]} />
                        <Text style={[styles.subMenuLabel, isActive && styles.subMenuLabelActive]}>
                          {sub.label}
                        </Text>
                      </TouchableOpacity>
                    );
                  })}
                </View>
              )}
            </View>
          );
        })}

        <TouchableOpacity
          style={styles.menuItem}
          onPress={() => setConfirmingLogout(true)}
          activeOpacity={0.75}
        >
          <Ionicons name="log-out-outline" size={18} color="rgba(255,255,255,0.85)" style={styles.menuIcon} />
          <Text style={styles.menuLabel}>Logout</Text>
        </TouchableOpacity>
      </ScrollView>

      {/* Profile footer — tap the name/avatar area to open your own
          profile (edit your photo/phone); the small power icon stays a
          separate, more deliberate logout action so tapping your own
          name never accidentally signs you out. */}
      <View style={styles.profileFooter}>
        <TouchableOpacity
          style={styles.profileFooterMain}
          onPress={() => onNavigate('profile:me')}
          activeOpacity={0.7}
          accessibilityLabel="View my profile"
        >
          <View style={styles.avatar}>
            {staffPhotoUrl ? (
              <Image source={{ uri: staffPhotoUrl }} style={styles.avatarImage} />
            ) : (
              <Text style={styles.avatarText}>{staffName.charAt(0).toUpperCase()}</Text>
            )}
          </View>
          <View style={styles.profileTextWrap}>
            <Text style={styles.profileName} numberOfLines={1}>{staffName}</Text>
            <Text style={styles.profileRole} numberOfLines={1}>{staffRole}</Text>
          </View>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => setConfirmingLogout(true)} style={styles.quickLogout} accessibilityLabel="Log out">
          <Ionicons name="power-outline" size={16} color={colors.white} />
        </TouchableOpacity>
      </View>

      <ConfirmDialog
        visible={confirmingLogout}
        title="Log Out?"
        message="Are you sure you want to log out?"
        confirmLabel="Yes"
        cancelLabel="No"
        destructive
        onCancel={() => setConfirmingLogout(false)}
        onConfirm={() => {
          setConfirmingLogout(false);
          onLogout && onLogout();
        }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  fixedWrap: {
    width: SIDEBAR_WIDTH,
    height: '100%',
  },
  overlayBackdrop: {
    flex: 1,
    flexDirection: 'row',
    backgroundColor: 'rgba(0,0,0,0.4)',
  },
  overlayPanel: {
    width: SIDEBAR_WIDTH,
    height: '100%',
  },
  backdropTapArea: {
    flex: 1,
  },

  sidebar: {
    width: SIDEBAR_WIDTH,
    height: '100%',
    backgroundColor: colors.primary,
    borderRightWidth: 1,
    borderRightColor: 'rgba(255,255,255,0.08)',
  },

  // Header
  header: {
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.xl,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.1)',
    alignItems: 'center',
  },
  logoImage: {
    width: 44,
    height: 44,
    marginBottom: spacing.sm,
  },
  logoBadge: {
    width: 44,
    height: 44,
    borderRadius: 22,
    borderWidth: 1.5,
    borderColor: 'rgba(255,255,255,0.3)',
    borderStyle: 'dashed',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: spacing.sm,
  },
  logoBadgeText: {
    fontSize: 8,
    fontFamily: fonts.bodySemiBold,
    color: 'rgba(255,255,255,0.6)',
  },
  brandName: {
    fontSize: 17,
    fontFamily: fonts.headingExtraBold,
    color: colors.white,
    letterSpacing: 0.3,
  },
  brandSubtitle: {
    fontSize: 10,
    fontFamily: fonts.body,
    color: 'rgba(255,255,255,0.6)',
    textAlign: 'center',
    marginTop: 2,
  },

  // Menu
  menuScroll: {
    flex: 1,
    paddingVertical: spacing.sm,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: spacing.sm + 2,
    paddingHorizontal: spacing.lg,
  },
  menuItemActive: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderLeftWidth: 3,
    borderLeftColor: colors.accent,
  },
  menuIcon: {
    width: 24,
  },
  menuLabel: {
    flex: 1,
    fontSize: 15,
    fontFamily: fonts.bodySemiBold,
    color: 'rgba(255,255,255,0.85)',
  },
  menuLabelActive: {
    color: colors.white,
  },
  chevron: {
    fontSize: 11,
    color: 'rgba(255,255,255,0.5)',
  },

  // Sub-menu
  subMenu: {
    paddingBottom: spacing.xs,
  },
  subMenuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: spacing.sm,
    paddingLeft: spacing.lg + 24,
    paddingRight: spacing.lg,
  },
  subMenuItemActive: {
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  subDot: {
    width: 5,
    height: 5,
    borderRadius: 3,
    backgroundColor: 'rgba(255,255,255,0.35)',
    marginRight: spacing.sm,
  },
  subDotActive: {
    backgroundColor: colors.accent,
  },
  subMenuLabel: {
    fontSize: 14,
    fontFamily: fonts.body,
    color: 'rgba(255,255,255,0.65)',
    flexShrink: 1,
  },
  subMenuLabelActive: {
    color: colors.white,
    fontFamily: fonts.bodySemiBold,
  },

  // Profile footer
  profileFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.1)',
  },
  profileFooterMain: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
  },
  avatar: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: colors.accent,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: spacing.sm,
    overflow: 'hidden',
  },
  avatarImage: {
    width: 44,
    height: 44,
  },
  avatarText: {
    color: colors.white,
    fontFamily: fonts.headingBold,
    fontSize: 16,
  },
  profileTextWrap: {
    flex: 1,
  },
  profileName: {
    fontSize: 14,
    fontFamily: fonts.bodySemiBold,
    color: colors.white,
  },
  profileRole: {
    fontSize: 11,
    fontFamily: fonts.body,
    color: 'rgba(255,255,255,0.6)',
    marginTop: 1,
  },
  quickLogout: {
    width: 30,
    height: 30,
    borderRadius: 15,
    backgroundColor: 'rgba(255,255,255,0.1)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  quickLogoutIcon: {
    fontSize: 14,
    color: colors.white,
  },
});