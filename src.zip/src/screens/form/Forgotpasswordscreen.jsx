import React, { useState, useEffect, useRef } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  KeyboardAvoidingView, Platform, ScrollView, ActivityIndicator, Image, Animated,
} from 'react-native';
// RESOLVED: SafeAreaView moved to 'react-native-safe-area-context' — see
// the same fix's full explanation in LoginScreen.jsx.
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '../../services/supabase';
import { colors, spacing, radius, fonts } from '../../utils/theme';

// Where Supabase sends the user after they click the reset link in their
// email — now landing on ResetPasswordScreen.jsx (wired up in App.jsx),
// which actually lets them set a new password. Previously this was a
// hardcoded placeholder domain, so the email went out but the link had
// nowhere real to go.
//
// On web, computed from the page's own origin at send-time instead of a
// fixed string — works automatically whether that's localhost during
// `expo start --web`, a Vercel preview URL, or the production domain,
// with nothing to hardcode or update on deploy.
//
// Native has no page origin to read, so FALLBACK_WEB_ORIGIN is used there
// instead. That's fine, not a workaround: there's no deep-link scheme
// registered for this app (see app.json — no "scheme" key), so the email
// link always opens in a browser regardless of platform. A guest tapping
// it on their phone just finishes the reset on this same web app, the
// same as on desktop, then switches back to the app to log in.
//
// EITHER WAY: whatever origin(s) this resolves to MUST also be added to
// Supabase Dashboard → Authentication → URL Configuration → Redirect
// URLs (e.g. https://your-domain.vercel.app/* — wildcards are allowed,
// which covers every preview deployment in one entry), or Supabase will
// reject the redirect and the link will fail even though the email sends
// fine.
const FALLBACK_WEB_ORIGIN = 'https://your-app-domain.example.com'; // TODO: set to your deployed web URL if this app ships on native.

const getPasswordResetRedirectUrl = () => {
  if (Platform.OS === 'web' && typeof window !== 'undefined') {
    return `${window.location.origin}/reset-password`;
  }
  return `${FALLBACK_WEB_ORIGIN}/reset-password`;
};

const RESEND_COOLDOWN_SECONDS = 60;

export default function ForgotPasswordScreen({ onLoginPress }) {
  const [value, setValue]     = useState('');
  const [focused, setFocused] = useState(false);
  const [error, setError]     = useState('');
  const [loading, setLoading] = useState(false);
  const [sent, setSent]       = useState(false);
  const [cooldown, setCooldown] = useState(0);

  const timerRef = useRef(null);

  // Smooth entrance whenever this screen mounts — e.g. coming here from
  // Login feels like a continuation, not an abrupt cut.
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(16)).current;
  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 320, useNativeDriver: true }),
      Animated.timing(slideAnim, { toValue: 0, duration: 320, useNativeDriver: true }),
    ]).start();
  }, []);

  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  const startCooldown = () => {
    setCooldown(RESEND_COOLDOWN_SECONDS);
    if (timerRef.current) clearInterval(timerRef.current);
    timerRef.current = setInterval(() => {
      setCooldown(prev => {
        if (prev <= 1) {
          clearInterval(timerRef.current);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const sendResetEmail = async () => {
    if (!value.trim()) {
      setError('Please enter your email address.');
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value.trim())) {
      setError('Please enter a valid email address.');
      return;
    }
    setError('');
    setLoading(true);
    try {
      // Supabase already doesn't reveal whether the email exists — it
      // returns success either way for security, same end behavior the
      // old auth/user-not-found branch was manually faking.
      const { error: resetError } = await supabase.auth.resetPasswordForEmail(value.trim(), {
        redirectTo: getPasswordResetRedirectUrl(),
      });
      if (resetError) throw resetError;
      setSent(true);
      startCooldown();
    } catch (e) {
      const msg = (e.message || '').toLowerCase();
      if (msg.includes('invalid') && msg.includes('email')) {
        setError('Please enter a valid email address.');
      } else if (e.status === 429 || msg.includes('rate limit') || msg.includes('too many')) {
        setError('Too many attempts. Please wait a bit before trying again.');
      } else {
        setError('Something went wrong. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = () => sendResetEmail();
  const handleResend = () => {
    if (cooldown > 0 || loading) return;
    sendResetEmail();
  };

  const handleUseDifferentEmail = () => {
    setSent(false);
    setError('');
    setValue('');
    setCooldown(0);
    if (timerRef.current) clearInterval(timerRef.current);
  };

  return (
    <SafeAreaView style={styles.safe}>
      <KeyboardAvoidingView style={styles.flex} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
        <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled">
          <Animated.View style={[styles.card, { opacity: fadeAnim, transform: [{ translateY: slideAnim }] }]}>

            {/* Logo */}
            <View style={styles.logoBadge}>
              <Image
                source={require('../../../assets/logo.png')}
                style={styles.logoImage}
                resizeMode="contain"
              />
            </View>

            <Text style={styles.title}>Forgot Password</Text>
            <Text style={styles.subtitle}>
              Enter your email address{'\n'}to receive a password reset link.
            </Text>

            {!sent ? (
              <>
                <View style={styles.fieldGroup}>
                  <Text style={styles.label}>Email Address:</Text>
                  <View style={[styles.inputWrap, focused && styles.inputWrapFocused, !!error && styles.inputWrapError]}>
                    <Ionicons name="mail-outline" size={18} color={focused ? colors.text : colors.textMuted} style={styles.inputIcon} />
                    <TextInput
                      style={styles.input}
                      placeholder="Enter your email address..."
                      placeholderTextColor={colors.disabled}
                      value={value}
                      onChangeText={v => { setValue(v); if (error) setError(''); }}
                      onFocus={() => setFocused(true)}
                      onBlur={() => setFocused(false)}
                      autoCapitalize="none"
                      autoCorrect={false}
                      keyboardType="email-address"
                    />
                  </View>
                  {!!error
                    ? <Text style={styles.errorText}>{error}</Text>
                    : <Text style={styles.hintText}>We'll send a reset link to your registered email address.</Text>
                  }
                </View>

                <TouchableOpacity style={[styles.primaryButton, loading && styles.buttonDisabled]} onPress={handleSubmit} activeOpacity={0.85} disabled={loading}>
                  {loading
                    ? <ActivityIndicator color={colors.white} />
                    : <Text style={styles.primaryButtonText}>Send Reset Link</Text>
                  }
                </TouchableOpacity>
              </>
            ) : (
              <View style={styles.successBox}>
                <Ionicons name="checkmark-circle-outline" size={56} color={colors.primary} />
                <Text style={styles.successTitle}>Check your email!</Text>
                <Text style={styles.successText}>
                  If an account exists for{' '}
                  <Text style={styles.successHighlight}>{value}</Text>
                  , a password reset link has been sent.
                </Text>

                {/* Spam / junk folder callout */}
                <View style={styles.spamCallout}>
                  <Ionicons name="alert-circle-outline" size={18} color={colors.accent} style={{ marginTop: 1 }} />
                  <View style={{ flex: 1 }}>
                    <Text style={styles.spamCalloutTitle}>Don't see it in your inbox?</Text>
                    <Text style={styles.spamCalloutText}>
                      Check your Spam or Junk folder — the email can sometimes land there.
                      It may also take a few minutes to arrive.
                    </Text>
                  </View>
                </View>

                {/* Resend */}
                <View style={styles.resendRow}>
                  <Text style={styles.resendLabel}>Still nothing?</Text>
                  <TouchableOpacity
                    onPress={handleResend}
                    disabled={cooldown > 0 || loading}
                    activeOpacity={0.7}
                  >
                    {loading ? (
                      <ActivityIndicator size="small" color={colors.primary} />
                    ) : (
                      <Text style={[styles.resendLink, cooldown > 0 && styles.resendLinkDisabled]}>
                        {cooldown > 0 ? `Resend in ${cooldown}s` : 'Resend email'}
                      </Text>
                    )}
                  </TouchableOpacity>
                </View>

                <TouchableOpacity onPress={handleUseDifferentEmail} activeOpacity={0.7}>
                  <Text style={styles.useDifferentEmailText}>Use a different email address</Text>
                </TouchableOpacity>
              </View>
            )}

            <View style={styles.divider} />

            <TouchableOpacity style={styles.secondaryButton} onPress={onLoginPress} activeOpacity={0.85}>
              <Text style={styles.secondaryButtonText}>Back to Log In</Text>
            </TouchableOpacity>

          </Animated.View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe:   { flex: 1, backgroundColor: colors.cardAlt },
  flex:   { flex: 1 },
  scroll: { flexGrow: 1, alignItems: 'center', justifyContent: 'center', padding: spacing.xl },

  card: {
    backgroundColor: colors.card,
    borderRadius: radius.lg,
    padding: spacing.xxl,
    width: '100%',
    maxWidth: 420,
    alignItems: 'center',
    ...Platform.select({
      web: { boxShadow: '0 20px 50px rgba(0,0,0,0.16)' },
      default: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 10 },
        shadowOpacity: 0.14,
        shadowRadius: 24,
        elevation: 8,
      },
    }),
  },

  logoBadge: { width: 80, height: 80, borderRadius: radius.lg, backgroundColor: colors.white, borderWidth: 1, borderColor: colors.border, alignItems: 'center', justifyContent: 'center', marginBottom: spacing.lg, overflow: 'hidden' },
  logoImage: { width: 56, height: 56 },

  title:    { fontFamily: fonts.headingExtraBold, fontSize: 24, color: colors.primary, marginBottom: spacing.xs, textAlign: 'center' },
  subtitle: { fontFamily: fonts.body, fontSize: 14, color: colors.textMuted, marginBottom: spacing.xl, textAlign: 'center', lineHeight: 21 },

  fieldGroup:       { width: '100%', marginBottom: spacing.md },
  label:            { fontFamily: fonts.bodyMedium, fontSize: 13, color: colors.text, marginBottom: spacing.xs },
  inputWrap:        { flexDirection: 'row', alignItems: 'center', height: 46, borderRadius: radius.md, borderWidth: 1, borderColor: colors.border, backgroundColor: colors.cardAlt, paddingHorizontal: spacing.md, gap: spacing.sm },
  inputWrapFocused: { borderColor: colors.primary, backgroundColor: colors.card },
  inputWrapError:   { borderColor: colors.danger,  backgroundColor: colors.dangerBg },
  inputIcon:        { flexShrink: 0 },
  input:            { flex: 1, fontFamily: fonts.body, fontSize: 14, color: colors.text, outlineStyle: 'none' },
  hintText:         { fontFamily: fonts.body, fontSize: 12, color: colors.textMuted, marginTop: spacing.xs, lineHeight: 18 },
  errorText:        { fontFamily: fonts.body, fontSize: 12, color: colors.danger, marginTop: spacing.xs },

  primaryButton:     { width: '100%', height: 48, borderRadius: 999, backgroundColor: colors.primary, alignItems: 'center', justifyContent: 'center', marginTop: spacing.xs },
  primaryButtonText: { fontFamily: fonts.headingSemiBold, fontSize: 15, color: colors.white, letterSpacing: 0.2 },
  buttonDisabled:    { opacity: 0.7 },

  successBox:       { width: '100%', alignItems: 'center', paddingVertical: spacing.lg, gap: spacing.md },
  successTitle:     { fontFamily: fonts.headingBold, fontSize: 18, color: colors.primary },
  successText:      { fontFamily: fonts.body, fontSize: 14, color: colors.textMuted, textAlign: 'center', lineHeight: 21 },
  successHighlight: { fontFamily: fonts.bodySemiBold, color: colors.primary },

  spamCallout: {
    flexDirection: 'row', gap: spacing.sm, width: '100%',
    backgroundColor: colors.accentTint, borderRadius: radius.md,
    borderWidth: 1, borderColor: colors.accent,
    padding: spacing.md,
  },
  spamCalloutTitle: { fontFamily: fonts.bodySemiBold, fontSize: 13, color: colors.text, marginBottom: 2 },
  spamCalloutText:  { fontFamily: fonts.body, fontSize: 12, color: colors.textMuted, lineHeight: 17 },

  resendRow: { flexDirection: 'row', alignItems: 'center', gap: spacing.xs, marginTop: spacing.xs },
  resendLabel: { fontFamily: fonts.body, fontSize: 13, color: colors.textMuted },
  resendLink: { fontFamily: fonts.bodySemiBold, fontSize: 13, color: colors.primary, textDecorationLine: 'underline' },
  resendLinkDisabled: { color: colors.disabled, textDecorationLine: 'none' },

  useDifferentEmailText: { fontFamily: fonts.body, fontSize: 12, color: colors.textMuted, textDecorationLine: 'underline', marginTop: spacing.xs },

  divider: { width: '100%', height: 0.5, backgroundColor: colors.border, marginVertical: spacing.lg },

  secondaryButton:     { width: '100%', height: 48, borderRadius: 999, borderWidth: 1.5, borderColor: colors.accent, backgroundColor: colors.accentTint, alignItems: 'center', justifyContent: 'center' },
  secondaryButtonText: { fontFamily: fonts.headingSemiBold, fontSize: 15, color: colors.accent, letterSpacing: 0.2 },
});