import React, { useState } from 'react';
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  StyleSheet,
  Platform,
  useWindowDimensions,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { colors, spacing, fonts } from '../../utils/theme';

const WIDE_SCREEN_BREAKPOINT = 768;

const CONTENT_PADDING_TOP = Platform.select({
  ios: spacing.sm,
  android: spacing.sm,
  default: spacing.md,
});

const CONTENT_PADDING_BOTTOM = Platform.select({
  ios: spacing.sm,
  android: spacing.sm,
  default: spacing.md,
});

/**
 * HomeHeader — logo + InnVision name + dynamic CTA + nav/hamburger.
 *
 * Safe-area note: this header does NOT call useSafeAreaInsets() itself.
 * The app's root SafeAreaView (in App.jsx, imported from
 * 'react-native-safe-area-context') already applies the top inset to every
 * screen it wraps, including the one that renders this header. Adding a
 * second inset here would double-pad the header — that's exactly what
 * happened during initial development, which is why this component went
 * through an inset-handling change and back. If this header is ever
 * rendered somewhere NOT wrapped by that root SafeAreaView, re-add
 * useSafeAreaInsets() here at that point — don't add it preemptively.
 *
 * CTA button behavior:
 *  - isAuthenticated = false  →  shows "SIGN IN"  (calls onSignIn)
 *  - isAuthenticated = true   →  shows "BOOK NOW" (calls onBookNow)
 *
 * Props:
 *  - onBookNow:        () => void
 *  - onSignIn:         () => void
 *  - onMenuPress:      () => void
 *  - onProfilePress:   () => void
 *  - onAboutPress:     () => void
 *  - onContactPress:   () => void
 *  - onFindBooking:    () => void   — navigate to the booking lookup screen
 *  - onOrderFood:      () => void   — navigate to Order Food (wide-screen nav
 *                                     only; mobile still reaches it via the
 *                                     hamburger menu, which already had it)
 *  - isAuthenticated:  boolean
 */
export default function HomeHeader({
  onBookNow,
  onSignIn,
  onMenuPress,
  onProfilePress,
  onAboutPress,
  onContactPress,
  onFindBooking,
  onOrderFood,
  onReportIssue,
  isAuthenticated,
  onHomePress,
}) {
  const { width } = useWindowDimensions();
  // Tracks which single element (by label) currently has the mouse
  // over it — React Native Web forwards onMouseEnter/onMouseLeave to
  // the underlying DOM node, which is how "hover" works here (there's
  // no native RN concept of it; on a phone/tablet these events simply
  // never fire, so this harmlessly does nothing there).
  const [hoveredNav, setHoveredNav] = useState(null);
  const [ctaHovered, setCtaHovered] = useState(false);
  const [logoHovered, setLogoHovered] = useState(false);
  const [menuBtnHovered, setMenuBtnHovered] = useState(false);
  const isWideScreen = width >= WIDE_SCREEN_BREAKPOINT;

  const handleCtaPress = () => {
    if (isAuthenticated) {
      onBookNow && onBookNow();
    } else {
      onSignIn && onSignIn();
    }
  };

  // Nav items — Order Food and Profile only shown when authenticated,
  // since ordering food requires a checked-in reservation (same gate
  // App.jsx already applies before routing to Order Food elsewhere).
  const navItems = [
    { label: 'About',            onPress: () => onAboutPress && onAboutPress() },
    { label: 'Promos',           onPress: () => {} },
    { label: 'Contact Us',       onPress: () => onContactPress && onContactPress() },
    { label: 'My Reservations',  onPress: () => onFindBooking && onFindBooking() },
    ...(isAuthenticated
      ? [{ label: 'Order Food', onPress: () => onOrderFood && onOrderFood() }]
      : []
    ),
    ...(isAuthenticated
      ? [{ label: 'Report an Issue', onPress: () => onReportIssue && onReportIssue() }]
      : []
    ),
    ...(isAuthenticated
      ? [{ label: 'Profile', onPress: () => onProfilePress && onProfilePress(), isAccent: true }]
      : []
    ),
  ];

  return (
    <View style={styles.shadowWrap}>
      <BlurView
        intensity={40}
        tint="light"
        style={styles.blur}
        experimentalBlurMethod="dimezisBlurView"
      >
        <View style={styles.tint} />

        <View style={styles.content}>

          {/* ── Logo ─────────────────────────────────────────── */}
          <TouchableOpacity
            style={[styles.logoRow, logoHovered && styles.logoRowHovered]}
            activeOpacity={0.8}
            onPress={onHomePress}
            onMouseEnter={() => setLogoHovered(true)}
            onMouseLeave={() => setLogoHovered(false)}
          >
            <Image
              source={require('../../../assets/logo.png')}
              style={styles.logoImage}
            />
            <Text style={styles.name} numberOfLines={1}>InnVision</Text>
          </TouchableOpacity>

          {/* ── Right side ───────────────────────────────────── */}
          <View style={styles.navRight}>

            {/* Wide screen nav links */}
            {isWideScreen && (
              <View style={styles.navLinks}>
                {navItems.map(item => {
                  const isHovered = hoveredNav === item.label;
                  return (
                    <TouchableOpacity
                      key={item.label}
                      style={styles.navLinkItem}
                      onPress={item.onPress}
                      activeOpacity={0.7}
                      onMouseEnter={() => setHoveredNav(item.label)}
                      onMouseLeave={() => setHoveredNav(null)}
                    >
                      <Text style={[styles.navLinkText, item.isAccent && styles.navLinkAccent, isHovered && styles.navLinkHovered]}>
                        {item.label}
                      </Text>
                      <View style={[styles.navLinkUnderline, isHovered && styles.navLinkUnderlineVisible]} />
                    </TouchableOpacity>
                  );
                })}
              </View>
            )}

            {/* CTA button */}
            <TouchableOpacity
              style={[
                styles.ctaButton,
                isAuthenticated ? styles.ctaBookNow : styles.ctaSignIn,
                ctaHovered && styles.ctaHovered,
              ]}
              onPress={handleCtaPress}
              activeOpacity={0.85}
              onMouseEnter={() => setCtaHovered(true)}
              onMouseLeave={() => setCtaHovered(false)}
            >
              <Text style={styles.ctaText}>
                {isAuthenticated ? 'BOOK NOW' : 'SIGN IN'}
              </Text>
            </TouchableOpacity>

            {/* Hamburger — mobile only. 44x44 touch target with extra
                inset from the screen edge, per accessibility guidelines. */}
            {!isWideScreen && (
              <TouchableOpacity
                style={[styles.menuButton, menuBtnHovered && styles.menuButtonHovered]}
                onPress={onMenuPress}
                hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
                accessibilityLabel="Open menu"
                accessibilityRole="button"
                onMouseEnter={() => setMenuBtnHovered(true)}
                onMouseLeave={() => setMenuBtnHovered(false)}
              >
                <View style={styles.menuLinesWrap}>
                  <View style={styles.menuLine} />
                  <View style={styles.menuLine} />
                  <View style={styles.menuLine} />
                </View>
              </TouchableOpacity>
            )}
          </View>
        </View>
      </BlurView>
    </View>
  );
}

const styles = StyleSheet.create({
  shadowWrap: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.08,
    shadowRadius: 8,
    elevation: 3,
  },
  blur: {
    overflow: 'hidden',
  },
  tint: {
    position: 'absolute',
    top: 0, left: 0, right: 0, bottom: 0,
    // Matches theme.js lightColors.background (#F5EFE6). Opacity raised to
    // 0.94 (from 0.72) because BlurView's tint="light" renders its own
    // native whitish blur backdrop underneath — at lower opacity that
    // native white was bleeding through and washing out the cream color,
    // making the header read white instead of cream. If the background
    // token in theme.js changes, update the rgb values to match (keep the
    // alpha near 0.9+ for the same reason).
    backgroundColor: 'rgba(245,239,230,0.94)',
  },
  content: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    // At narrow phone widths the logo + name + CTA + hamburger can
    // overflow a non-wrapping row and clip the right-side CTA.
    // Allow the row itself to wrap so nothing gets pushed off-screen.
    flexWrap: 'wrap',
    paddingHorizontal: spacing.lg,
    paddingTop: CONTENT_PADDING_TOP,
    paddingBottom: CONTENT_PADDING_BOTTOM,
  },

  // Logo
  logoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    flexShrink: 1,
    marginRight: spacing.sm,
  },
  logoRowHovered: {
    opacity: 0.75,
  },
  logoImage: {
    width: 44,
    height: 44,
    borderRadius: 10,
    marginRight: spacing.sm,
    resizeMode: 'contain',
  },
  name: {
    fontSize: 16,
    fontFamily: fonts.headingExtraBold,
    color: colors.primary,
    letterSpacing: 0.3,
    flexShrink: 1,
  },

  // Nav
  navRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: spacing.sm,
    flexShrink: 1,
    marginLeft: 'auto',
  },
  navLinks: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: spacing.sm,
  },
  navLinkItem: {
    marginHorizontal: spacing.sm,
    alignItems: 'center',
  },
  navLinkText: {
    fontSize: 14,
    fontFamily: fonts.headingSemiBold,
    color: colors.text,
  },
  navLinkHovered: {
    color: colors.primary,
  },
  navLinkAccent: {
    color: colors.primary,
    fontFamily: fonts.headingBold,
    textDecorationLine: 'underline',
    textDecorationColor: colors.accent,
    textDecorationStyle: 'solid',
  },
  // A small underline that fades in on hover — invisible (transparent)
  // by default rather than absent, so its reserved space doesn't cause
  // the row to shift height when a link becomes hovered.
  navLinkUnderline: {
    width: 14,
    height: 2,
    borderRadius: 1,
    marginTop: 3,
    backgroundColor: 'transparent',
  },
  navLinkUnderlineVisible: {
    backgroundColor: colors.accent,
  },

  // CTA
  ctaButton: {
    borderRadius: 999,
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.lg,
    flexShrink: 1,
  },
  ctaBookNow: {
    backgroundColor: colors.step,
  },
  ctaSignIn: {
    backgroundColor: colors.primary,
  },
  ctaHovered: {
    opacity: 0.88,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 4,
    elevation: 2,
  },
  ctaText: {
    color: colors.white,
    fontFamily: fonts.headingSemiBold,
    fontSize: 11,
    letterSpacing: 0.5,
  },

  // Hamburger — outer touchable is a full 44x44 target; inner lines stay
  // visually compact and centered within it.
  menuButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: spacing.xs,
    marginRight: -spacing.xs, // keeps the visible icon aligned with content edge despite the larger tap target
  },
  menuButtonHovered: {
    backgroundColor: 'rgba(0,0,0,0.05)',
  },
  menuLinesWrap: {
    width: 24,
    height: 18,
    justifyContent: 'space-between',
  },
  menuLine: {
    height: 2,
    borderRadius: 1,
    backgroundColor: colors.primary,
  },
});