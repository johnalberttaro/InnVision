import React, { useEffect, useMemo, useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  TextInput,
  Image,
  StyleSheet,
  ActivityIndicator,
  SafeAreaView,
  useWindowDimensions,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '../../services/supabase';
import { useTheme } from '../../context/ThemeContext';

/**
 * OrderFoodScreen — Food & Dining, Phase 1 of the Food Service module.
 *
 * SCOPE (Phase 1 only): a guest with a checked-in reservation can browse
 * the menu, build a cart, and place an order. That's it. There is
 * deliberately no in-app payment step — see the note below.
 *
 * NOT YET BUILT (later phases, same module):
 *  - Phase 2: Front Desk sees incoming orders and escalates them to
 *    Kitchen/F&B (a new screen in the Front Desk Portal).
 *  - Phase 3: a brand new Kitchen/F&B portal (its own role, login
 *    routing, and sidebar — separate from Housekeeping) where staff
 *    prepare orders and assign a staff member to deliver.
 *  - Phase 4: an Admin screen to manage the food menu — for now, menu
 *    items are edited directly in Supabase's Table Editor (see
 *    supabase/migrations/001_food_service_phase1.sql for the seed data).
 * An order placed here will just sit at status 'pending' until Phase 2
 * exists — that's expected, not a bug.
 *
 * PAYMENT: orders are paid ON DELIVERY, not through the app. Once the
 * later phases exist, the staff member who delivers the order brings the
 * itemized bill and an e-wallet QR code, and the guest pays cash or
 * e-wallet right there. There is no payment gateway call in this screen —
 * that's intentional, not missing.
 *
 * ELIGIBILITY: only guests with a status = 'checked-in' reservation can
 * order — there needs to be a real, current room to deliver to. This is
 * enforced twice: here (for a clear message instead of a confusing
 * empty screen) and again by the database's own RLS policy on
 * food_orders, so it can't be bypassed by going around this screen.
 *
 * Props:
 *  - user: Supabase Auth user object (user.id, user.email)
 *  - onBackPress: () => void
 */
export default function OrderFoodScreen({ user, onBackPress }) {
  const { colors, spacing, radius, fonts } = useTheme();
  const { width } = useWindowDimensions();
  const isWide = width >= 860;
  const styles = useMemo(() => getStyles(colors, spacing, radius, fonts), [colors, spacing, radius, fonts]);

  const [loading, setLoading] = useState(true);
  const [checkedInReservation, setCheckedInReservation] = useState(null);
  const [menuItems, setMenuItems] = useState([]);
  const [cart, setCart] = useState({}); // { [menuItemId]: quantity }
  const [notes, setNotes] = useState('');
  const [view, setView] = useState('menu'); // 'menu' | 'cart' | 'confirmed'
  const [placingOrder, setPlacingOrder] = useState(false);
  const [orderError, setOrderError] = useState('');
  const [activeCategory, setActiveCategory] = useState('All');

  // Find the guest's current checked-in stay — that's the room the order
  // gets delivered to. If there's more than one (rare — e.g. multiple
  // rooms on one trip), the first one found is used; a later phase can
  // add a room picker if that turns out to matter in practice.
  useEffect(() => {
    if (!user?.id) return;
    let cancelled = false;

    const load = async () => {
      const { data, error } = await supabase
        .from('reservations')
        .select('id, status, selected_rooms, guest_details, guest_email')
        .eq('user_id', user.id)
        .eq('status', 'checked-in')
        .order('created_at', { ascending: false })
        .limit(1);
      if (!cancelled) {
        if (error) {
          console.error('Failed to load checked-in reservation:', error);
        } else if (data && data.length > 0) {
          setCheckedInReservation(data[0]);
        }
      }
    };
    load();
    return () => { cancelled = true; };
  }, [user?.id]);

  useEffect(() => {
    let cancelled = false;
    const loadMenu = async () => {
      const { data, error } = await supabase
        .from('food_menu_items')
        .select('*')
        .eq('available', true)
        .order('category', { ascending: true })
        .order('name', { ascending: true });
      if (!cancelled) {
        if (error) console.error('Failed to load food menu:', error);
        setMenuItems(data || []);
        setLoading(false);
      }
    };
    loadMenu();
    return () => { cancelled = true; };
  }, []);

  const categories = useMemo(() => {
    const set = new Set(menuItems.map((m) => m.category));
    return ['All', ...Array.from(set)];
  }, [menuItems]);

  const visibleItems = useMemo(() => {
    if (activeCategory === 'All') return menuItems;
    return menuItems.filter((m) => m.category === activeCategory);
  }, [menuItems, activeCategory]);

  const roomNumber = useMemo(() => {
    const rooms = checkedInReservation?.selected_rooms;
    if (Array.isArray(rooms) && rooms.length > 0) {
      return rooms.map((r) => r.roomNumber || r.number || r.room).filter(Boolean).join(', ');
    }
    return null;
  }, [checkedInReservation]);

  const cartLines = useMemo(() => {
    return Object.entries(cart)
      .filter(([, qty]) => qty > 0)
      .map(([id, qty]) => {
        const item = menuItems.find((m) => m.id === id);
        return item ? { ...item, quantity: qty, subtotal: item.price * qty } : null;
      })
      .filter(Boolean);
  }, [cart, menuItems]);

  const cartCount = cartLines.reduce((sum, l) => sum + l.quantity, 0);
  const cartTotal = cartLines.reduce((sum, l) => sum + l.subtotal, 0);

  const adjustQty = (itemId, delta) => {
    setCart((prev) => {
      const next = Math.max(0, (prev[itemId] || 0) + delta);
      return { ...prev, [itemId]: next };
    });
  };

  const formatCurrency = (amount) => `₱${(amount || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

  const handlePlaceOrder = async () => {
    if (!checkedInReservation || cartLines.length === 0) return;
    setPlacingOrder(true);
    setOrderError('');
    try {
      const guestName = checkedInReservation.guest_details
        ? `${checkedInReservation.guest_details.firstName || ''} ${checkedInReservation.guest_details.lastName || ''}`.trim()
        : (checkedInReservation.guest_email || user.email || 'Guest');

      const { data: order, error: insertOrderError } = await supabase
        .from('food_orders')
        .insert({
          reservation_id: checkedInReservation.id,
          user_id: user.id,
          guest_name: guestName,
          room_number: roomNumber || 'Unknown',
          notes: notes.trim() || null,
          total_amount: cartTotal,
          placed_by: 'guest',
        })
        .select()
        .single();
      if (insertOrderError) throw insertOrderError;

      const orderItemsPayload = cartLines.map((l) => ({
        order_id: order.id,
        menu_item_id: l.id,
        item_name: l.name,
        unit_price: l.price,
        quantity: l.quantity,
        subtotal: l.subtotal,
      }));
      const { error: itemsError } = await supabase.from('food_order_items').insert(orderItemsPayload);
      if (itemsError) throw itemsError;

      setView('confirmed');
    } catch (err) {
      console.error('Failed to place food order:', err);
      setOrderError('Could not place your order. Please try again.');
    } finally {
      setPlacingOrder(false);
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.safe}>
        <View style={styles.centerWrap}><ActivityIndicator color={colors.primary} size="large" /></View>
      </SafeAreaView>
    );
  }

  // Not checked in — nothing to deliver to yet. Same rule the database
  // enforces on its own via RLS, so this is a friendly message, not the
  // only line of defense.
  if (!checkedInReservation) {
    return (
      <SafeAreaView style={styles.safe}>
        <View style={styles.centerWrap}>
          <Ionicons name="restaurant-outline" size={40} color={colors.textMuted} />
          <Text style={styles.emptyTitle}>Food ordering isn't available yet</Text>
          <Text style={styles.emptyText}>
            Room service becomes available once you've checked in. If you've just checked in, this may take a moment to update.
          </Text>
          {!!onBackPress && (
            <TouchableOpacity style={styles.backLinkBtn} onPress={onBackPress}>
              <Text style={styles.backLinkText}>Go back</Text>
            </TouchableOpacity>
          )}
        </View>
      </SafeAreaView>
    );
  }

  if (view === 'confirmed') {
    return (
      <SafeAreaView style={styles.safe}>
        <View style={styles.centerWrap}>
          <View style={styles.confirmIconWrap}>
            <Ionicons name="checkmark" size={32} color={colors.onPrimary} />
          </View>
          <Text style={styles.emptyTitle}>Order placed!</Text>
          <Text style={styles.emptyText}>
            Your order for Room {roomNumber} has been sent to our staff. When it's delivered, we'll bring an itemized bill and a QR code — you can pay by cash or e-wallet at that time.
          </Text>
          <TouchableOpacity
            style={styles.primaryBtn}
            onPress={() => {
              setCart({});
              setNotes('');
              setView('menu');
            }}
          >
            <Text style={styles.primaryBtnText}>Order More</Text>
          </TouchableOpacity>
          {!!onBackPress && (
            <TouchableOpacity style={styles.backLinkBtn} onPress={onBackPress}>
              <Text style={styles.backLinkText}>Back to Profile</Text>
            </TouchableOpacity>
          )}
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.headerBar}>
        <TouchableOpacity onPress={view === 'cart' ? () => setView('menu') : onBackPress} style={styles.headerBackBtn}>
          <Ionicons name="chevron-back" size={20} color={colors.primary} />
        </TouchableOpacity>
        <View style={{ flex: 1 }}>
          <Text style={styles.headerTitle}>{view === 'cart' ? 'Your Order' : 'Order Food'}</Text>
          <Text style={styles.headerSubtitle}>Delivering to Room {roomNumber}</Text>
        </View>
      </View>

      {view === 'menu' ? (
        <>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.categoryRow} contentContainerStyle={{ gap: spacing.xs }}>
            {categories.map((cat) => (
              <TouchableOpacity
                key={cat}
                style={[styles.categoryChip, activeCategory === cat && styles.categoryChipActive]}
                onPress={() => setActiveCategory(cat)}
              >
                <Text style={[styles.categoryChipText, activeCategory === cat && styles.categoryChipTextActive]}>{cat}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>

          <ScrollView contentContainerStyle={[styles.menuList, isWide && styles.menuListWide]} showsVerticalScrollIndicator={false}>
            {visibleItems.map((item) => {
              const qty = cart[item.id] || 0;
              return (
                <View key={item.id} style={[styles.menuCard, isWide && styles.menuCardWide]}>
                  {item.photo_url ? (
                    <Image source={{ uri: item.photo_url }} style={styles.menuPhoto} />
                  ) : (
                    <View style={styles.menuPhotoFallback}>
                      <Ionicons name="restaurant-outline" size={22} color={colors.textMuted} />
                    </View>
                  )}
                  <View style={{ flex: 1 }}>
                    <Text style={styles.menuName}>{item.name}</Text>
                    {!!item.description && <Text style={styles.menuDesc} numberOfLines={2}>{item.description}</Text>}
                    <Text style={styles.menuPrice}>{formatCurrency(item.price)}</Text>
                  </View>
                  {qty === 0 ? (
                    <TouchableOpacity style={styles.addBtn} onPress={() => adjustQty(item.id, 1)}>
                      <Text style={styles.addBtnText}>Add</Text>
                    </TouchableOpacity>
                  ) : (
                    <View style={styles.stepper}>
                      <TouchableOpacity style={styles.stepperBtn} onPress={() => adjustQty(item.id, -1)}>
                        <Ionicons name="remove" size={16} color={colors.primary} />
                      </TouchableOpacity>
                      <Text style={styles.stepperValue}>{qty}</Text>
                      <TouchableOpacity style={styles.stepperBtn} onPress={() => adjustQty(item.id, 1)}>
                        <Ionicons name="add" size={16} color={colors.primary} />
                      </TouchableOpacity>
                    </View>
                  )}
                </View>
              );
            })}
            <View style={{ height: 90 }} />
          </ScrollView>

          {cartCount > 0 && (
            <TouchableOpacity style={styles.cartBar} onPress={() => setView('cart')} activeOpacity={0.9}>
              <View style={styles.cartBarCountBadge}>
                <Text style={styles.cartBarCountText}>{cartCount}</Text>
              </View>
              <Text style={styles.cartBarText}>View Order</Text>
              <Text style={styles.cartBarTotal}>{formatCurrency(cartTotal)}</Text>
            </TouchableOpacity>
          )}
        </>
      ) : (
        <ScrollView contentContainerStyle={styles.cartScroll}>
          {cartLines.map((line) => (
            <View key={line.id} style={styles.cartLine}>
              <View style={{ flex: 1 }}>
                <Text style={styles.cartLineName}>{line.name}</Text>
                <Text style={styles.cartLineUnitPrice}>{formatCurrency(line.price)} each</Text>
              </View>
              <View style={styles.stepper}>
                <TouchableOpacity style={styles.stepperBtn} onPress={() => adjustQty(line.id, -1)}>
                  <Ionicons name="remove" size={16} color={colors.primary} />
                </TouchableOpacity>
                <Text style={styles.stepperValue}>{line.quantity}</Text>
                <TouchableOpacity style={styles.stepperBtn} onPress={() => adjustQty(line.id, 1)}>
                  <Ionicons name="add" size={16} color={colors.primary} />
                </TouchableOpacity>
              </View>
              <Text style={styles.cartLineSubtotal}>{formatCurrency(line.subtotal)}</Text>
            </View>
          ))}

          <Text style={styles.fieldLabel}>Notes for the kitchen (optional)</Text>
          <TextInput
            style={styles.notesInput}
            value={notes}
            onChangeText={setNotes}
            placeholder="e.g. No onions, extra spicy"
            placeholderTextColor={colors.disabled}
            multiline
          />

          <View style={styles.paymentNote}>
            <Ionicons name="information-circle-outline" size={16} color={colors.textMuted} />
            <Text style={styles.paymentNoteText}>
              Payment is collected when your order is delivered — our staff will bring the bill and a QR code so you can pay by cash or e-wallet.
            </Text>
          </View>

          {!!orderError && <Text style={styles.errorText}>{orderError}</Text>}

          <View style={styles.totalRow}>
            <Text style={styles.totalLabel}>Total</Text>
            <Text style={styles.totalValue}>{formatCurrency(cartTotal)}</Text>
          </View>

          <TouchableOpacity
            style={[styles.primaryBtn, (placingOrder || cartLines.length === 0) && styles.primaryBtnDisabled]}
            onPress={handlePlaceOrder}
            disabled={placingOrder || cartLines.length === 0}
          >
            {placingOrder ? <ActivityIndicator color={colors.onPrimary} /> : <Text style={styles.primaryBtnText}>Place Order</Text>}
          </TouchableOpacity>
        </ScrollView>
      )}
    </SafeAreaView>
  );
}

function getStyles(colors, spacing, radius, fonts) {
  return StyleSheet.create({
    safe: { flex: 1, backgroundColor: colors.background },
    centerWrap: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: spacing.xl },
    emptyTitle: { fontFamily: fonts.headingBold, fontSize: 17, color: colors.text, marginTop: spacing.md, textAlign: 'center' },
    emptyText: { fontFamily: fonts.body, fontSize: 13, color: colors.textMuted, textAlign: 'center', marginTop: spacing.xs, maxWidth: 320 },
    backLinkBtn: { marginTop: spacing.lg },
    backLinkText: { fontFamily: fonts.bodySemiBold, fontSize: 13, color: colors.primary },

    confirmIconWrap: { width: 56, height: 56, borderRadius: 28, backgroundColor: '#1E7B34', alignItems: 'center', justifyContent: 'center' },

    headerBar: { flexDirection: 'row', alignItems: 'center', padding: spacing.lg, gap: spacing.sm, borderBottomWidth: 1, borderBottomColor: colors.border },
    headerBackBtn: { width: 32, height: 32, borderRadius: 16, alignItems: 'center', justifyContent: 'center', backgroundColor: colors.cardAlt },
    headerTitle: { fontFamily: fonts.headingExtraBold, fontSize: 18, color: colors.primary },
    headerSubtitle: { fontFamily: fonts.body, fontSize: 12, color: colors.textMuted, marginTop: 1 },

    categoryRow: { paddingHorizontal: spacing.lg, paddingVertical: spacing.sm, flexGrow: 0 },
    categoryChip: { borderWidth: 1, borderColor: colors.border, borderRadius: 999, paddingVertical: 6, paddingHorizontal: spacing.md, backgroundColor: colors.cardAlt },
    categoryChipActive: { backgroundColor: colors.primary, borderColor: colors.primary },
    categoryChipText: { fontFamily: fonts.bodyMedium, fontSize: 12, color: colors.text },
    categoryChipTextActive: { color: colors.onPrimary, fontFamily: fonts.bodySemiBold },

    menuList: { padding: spacing.lg, gap: spacing.md },
    menuListWide: { flexDirection: 'row', flexWrap: 'wrap' },
    menuCard: {
      flexDirection: 'row', alignItems: 'center', gap: spacing.md,
      backgroundColor: colors.card, borderRadius: radius.lg, borderWidth: 1, borderColor: colors.border,
      padding: spacing.md,
    },
    menuCardWide: { width: '48%' },
    menuPhoto: { width: 56, height: 56, borderRadius: radius.md },
    menuPhotoFallback: { width: 56, height: 56, borderRadius: radius.md, backgroundColor: colors.cardAlt, alignItems: 'center', justifyContent: 'center' },
    menuName: { fontFamily: fonts.headingSemiBold, fontSize: 14, color: colors.text },
    menuDesc: { fontFamily: fonts.body, fontSize: 11.5, color: colors.textMuted, marginTop: 2 },
    menuPrice: { fontFamily: fonts.bodySemiBold, fontSize: 13, color: colors.primary, marginTop: 4 },

    addBtn: { backgroundColor: colors.primary, borderRadius: 999, paddingVertical: 8, paddingHorizontal: spacing.md },
    addBtnText: { fontFamily: fonts.bodySemiBold, fontSize: 12, color: colors.onPrimary },

    stepper: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm },
    stepperBtn: { width: 28, height: 28, borderRadius: 14, borderWidth: 1, borderColor: colors.border, alignItems: 'center', justifyContent: 'center' },
    stepperValue: { fontFamily: fonts.headingSemiBold, fontSize: 14, color: colors.text, minWidth: 18, textAlign: 'center' },

    cartBar: {
      position: 'absolute', bottom: spacing.lg, left: spacing.lg, right: spacing.lg,
      flexDirection: 'row', alignItems: 'center', gap: spacing.sm,
      backgroundColor: colors.primary, borderRadius: radius.lg, padding: spacing.md,
      shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.2, shadowRadius: 10, elevation: 6,
    },
    cartBarCountBadge: { backgroundColor: 'rgba(255,255,255,0.25)', borderRadius: 999, width: 24, height: 24, alignItems: 'center', justifyContent: 'center' },
    cartBarCountText: { fontFamily: fonts.bodySemiBold, fontSize: 12, color: colors.onPrimary },
    cartBarText: { flex: 1, fontFamily: fonts.headingSemiBold, fontSize: 14, color: colors.onPrimary },
    cartBarTotal: { fontFamily: fonts.headingExtraBold, fontSize: 14, color: colors.onPrimary },

    cartScroll: { padding: spacing.lg },
    cartLine: { flexDirection: 'row', alignItems: 'center', gap: spacing.sm, paddingVertical: spacing.sm, borderBottomWidth: 1, borderBottomColor: colors.border },
    cartLineName: { fontFamily: fonts.bodySemiBold, fontSize: 13, color: colors.text },
    cartLineUnitPrice: { fontFamily: fonts.body, fontSize: 11, color: colors.textMuted, marginTop: 1 },
    cartLineSubtotal: { fontFamily: fonts.headingSemiBold, fontSize: 13, color: colors.primary, minWidth: 70, textAlign: 'right' },

    fieldLabel: { fontFamily: fonts.bodyMedium, fontSize: 12, color: colors.text, marginTop: spacing.md, marginBottom: spacing.xs },
    notesInput: {
      borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, backgroundColor: colors.cardAlt,
      padding: spacing.sm, fontFamily: fonts.body, fontSize: 13, color: colors.text, minHeight: 70, textAlignVertical: 'top',
    },

    paymentNote: {
      flexDirection: 'row', gap: spacing.xs, backgroundColor: colors.cardAlt, borderRadius: radius.md,
      padding: spacing.sm, marginTop: spacing.md,
    },
    paymentNoteText: { flex: 1, fontFamily: fonts.body, fontSize: 11.5, color: colors.textMuted, lineHeight: 16 },

    errorText: { fontFamily: fonts.body, fontSize: 12, color: '#B3261E', marginTop: spacing.sm },

    totalRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: spacing.lg },
    totalLabel: { fontFamily: fonts.headingSemiBold, fontSize: 15, color: colors.text },
    totalValue: { fontFamily: fonts.headingExtraBold, fontSize: 20, color: colors.primary },

    primaryBtn: { backgroundColor: colors.primary, borderRadius: 999, paddingVertical: spacing.md, alignItems: 'center', justifyContent: 'center', marginTop: spacing.lg },
    primaryBtnDisabled: { opacity: 0.5 },
    primaryBtnText: { fontFamily: fonts.headingSemiBold, fontSize: 14, color: colors.onPrimary },
  });
}